Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/how-to-search-multiple-words-at-a-time-with-jquery-ajax/

Instructions -

## Import attached posts.sql file in your MySQL Database.
## Update config.php file.
